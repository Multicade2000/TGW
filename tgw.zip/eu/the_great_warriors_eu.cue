FILE "the_great_warriors_eu.bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
